package Strategy;

public class DisplayOnScreen implements IDisplay {

	@Override
	public void displayOrNot() {
		// TODO Auto-generated method stub
		
	}

}
