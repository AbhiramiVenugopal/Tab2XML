package Strategy;

public class FiveViewer implements IAlignmentBehavior {

}
