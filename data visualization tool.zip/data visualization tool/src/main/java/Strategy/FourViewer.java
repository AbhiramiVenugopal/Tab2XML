package Strategy;

public class FourViewer implements IAlignmentBehavior {

}
