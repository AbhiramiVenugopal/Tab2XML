package Strategy;

/*
 * strategy pattern, behavior interface
 * 
 */
public interface IAlignmentBehavior {
	
}
