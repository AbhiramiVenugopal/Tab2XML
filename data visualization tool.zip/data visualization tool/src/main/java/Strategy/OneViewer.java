package Strategy;

public class OneViewer implements IAlignmentBehavior {

}
