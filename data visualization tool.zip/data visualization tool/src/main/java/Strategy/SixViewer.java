package Strategy;

public class SixViewer implements IAlignmentBehavior {

}
