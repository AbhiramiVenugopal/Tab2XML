package Strategy;

public class ThreeViewer implements IAlignmentBehavior {

}
