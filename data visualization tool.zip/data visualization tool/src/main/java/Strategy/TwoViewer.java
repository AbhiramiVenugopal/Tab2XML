package Strategy;

public class TwoViewer implements IAlignmentBehavior{

}
